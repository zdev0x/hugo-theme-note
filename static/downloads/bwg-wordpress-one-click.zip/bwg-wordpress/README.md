# 搬瓦工 VPS：Docker + 宿主机 Caddy 部署 WordPress

版本：2.0.2

这套部署与当前搬瓦工生产结构一致：

```text
访客 → Cloudflare → 搬瓦工宿主机 Caddy
     → 127.0.0.1:8080（Docker Nginx）
     → PHP-FPM → MariaDB / Redis
```

- 宿主机运行 Caddy，不运行 Caddy 容器。
- Docker Compose 运行 Nginx、PHP-FPM、MariaDB、Redis。
- WordPress 文件直接位于 `/opt/docker/blog/www/`。
- PHP 镜像由包内 `Dockerfile` 构建，包含 GD、Intl、ZIP、MySQL 和 Redis 扩展。
- `.env` 首次生成随机数据库密码和 WordPress 密钥，重复执行时复用。
- 已存在的 `.env`、Compose、Nginx、PHP、Caddy 站点配置不会被覆盖。

## 使用

先检查包完整性：

```bash
sha256sum -c SHA256SUMS
```

然后查看脚本和配置：

```bash
less deploy-bwg-wordpress.sh
find templates -maxdepth 3 -type f
```

执行：

```bash
sudo bash deploy-bwg-wordpress.sh blog.example.com
```

部署后访问：

```text
https://blog.example.com/wp-admin/install.php
```

在浏览器中创建管理员。脚本不会输出默认管理员密码。

## 目录

```text
/opt/docker/blog/
├── .env
├── .bwg-wordpress-oneclick
├── docker-compose.yml
├── Dockerfile
├── nginx/
│   ├── nginx.conf
│   ├── default.conf
│   └── logs/
├── php/
│   ├── conf.d/99-blog.ini
│   └── php-fpm.d/zz-blog.ini
└── www/
    └── wp-config.php
```

`php-fpm.d/zz-blog.ini` 在 Compose 中挂载为容器内的 `zz-blog.conf`，这是有意为之，不是拼写错误。

## 可选环境变量

| 变量 | 默认值 | 用途 |
| --- | --- | --- |
| `INSTALL_DIR` | `/opt/docker/blog` | WordPress 部署目录 |
| `CADDY_CONFIG_ROOT` | `/etc/caddy` | 宿主机 Caddy 配置目录；自定义目录时必须同时设置 `SKIP_SERVICE_ACTIONS=1` |
| `COMPOSE_PROJECT_NAME` | `blog` | 容器和卷的项目前缀 |
| `BLOG_PORT` | `8080` | 宿主机回环 Nginx 端口 |
| `BLOG_SUBNET` | `172.19.0.0/24` | Docker 网络子网 |
| `BLOG_GATEWAY` | `172.19.0.1` | Nginx 可信网关 |
| `HTTP_PORT` | `80` | Caddy HTTP 端口，写入 `.env` 供复跑使用 |
| `HTTPS_PORT` | `443` | Caddy HTTPS 端口，写入 `.env` 供复跑使用 |
| `SKIP_DEPENDENCIES` | `0` | 为 `1` 时不安装系统依赖 |
| `SKIP_SERVICE_ACTIONS` | `0` | 为 `1` 时只校验，不启动/reload Caddy |
| `PULL_IMAGES` | `1` | 为 `0` 时不重新拉取镜像 |
| `WORDPRESS_DOWNLOAD_URL` | 官方 latest.tar.gz | WordPress 下载地址 |

还可以通过 `NGINX_IMAGE`、`MARIADB_IMAGE`、`REDIS_IMAGE`、`PHP_BASE_IMAGE` 覆盖镜像地址。

## 重复执行

重复执行会：

- 复用 `.env` 中的密码和密钥。
- 保留已有 WordPress 文件和配置。
- 校验 Compose 并重建需要更新的容器。
- 校验宿主机 Caddy 配置。
- 默认拉取镜像并执行 `up -d --build`。

修改单文件 bind mount 配置后，可能需要重建相应容器，而不仅是 reload。

## 管理

```bash
cd /opt/docker/blog
docker compose ps
docker compose logs --tail=100
docker compose down
docker compose up -d
```

`down` 保留数据。不要在普通停止时使用 `down -v`，否则会删除 MariaDB 数据卷。

## 安全说明

- MariaDB 和 Redis 不映射宿主机端口。
- Nginx 只监听宿主机 `127.0.0.1`。
- `.env` 权限为 `0600`，脚本不会打印其中的密码。
- `www/wp-config.php` 首次创建时权限收紧为 `0640`，复跑不会递归重写整个 `www/` 的所有权或权限。
- 脚本不会自动修改 Cloudflare DNS 或防火墙。
- 正式使用前仍需检查域名解析、TCP 80/443、UDP 443（可选 HTTP/3）和备份。

#!/usr/bin/env bash
# Deploy the BandwagonHost-style WordPress stack: host Caddy + Docker Nginx/PHP/MariaDB/Redis.
set -Eeuo pipefail
IFS=$'\n\t'
umask 077

VERSION='2.0.2'
INSTALL_DIR="${INSTALL_DIR:-/opt/docker/blog}"
CADDY_CONFIG_ROOT="${CADDY_CONFIG_ROOT:-/etc/caddy}"
REQUESTED_DOMAIN="${1:-${DOMAIN:-}}"
COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-blog}"
EXPLICIT_HTTP_PORT="${HTTP_PORT:-}"
EXPLICIT_HTTPS_PORT="${HTTPS_PORT:-}"
BLOG_PORT="${BLOG_PORT:-8080}"
BLOG_SUBNET="${BLOG_SUBNET:-172.19.0.0/24}"
BLOG_GATEWAY="${BLOG_GATEWAY:-172.19.0.1}"
HTTP_PORT="${HTTP_PORT:-80}"
HTTPS_PORT="${HTTPS_PORT:-443}"
SKIP_DEPENDENCIES="${SKIP_DEPENDENCIES:-0}"
SKIP_SERVICE_ACTIONS="${SKIP_SERVICE_ACTIONS:-0}"
PULL_IMAGES="${PULL_IMAGES:-1}"
WORDPRESS_DOWNLOAD_URL="${WORDPRESS_DOWNLOAD_URL:-https://wordpress.org/latest.tar.gz}"
MARKER='.bwg-wordpress-oneclick'
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log() { printf '\033[1;34m[INFO]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[WARN]\033[0m %s\n' "$*" >&2; }
die() { printf '\033[1;31m[ERROR]\033[0m %s\n' "$*" >&2; exit 1; }
trap 'die "Failed at line $LINENO. Review the output before rerunning."' ERR

if [[ "${1:-}" == '--help' || "${1:-}" == '-h' ]]; then
    cat <<'HELP'
Usage:
  sudo bash deploy-bwg-wordpress.sh blog.example.com

Defaults:
  INSTALL_DIR=/opt/docker/blog
  CADDY_CONFIG_ROOT=/etc/caddy
  COMPOSE_PROJECT_NAME=blog
  BLOG_PORT=8080
  BLOG_SUBNET=172.19.0.0/24
  BLOG_GATEWAY=172.19.0.1
  HTTP_PORT=80
  HTTPS_PORT=443

Optional:
  SKIP_DEPENDENCIES=1    Do not install system packages
  SKIP_SERVICE_ACTIONS=1 Validate configs but do not start/reload host Caddy
  PULL_IMAGES=0          Do not pull Docker images

The script expects the templates/ directory from the same package.
HELP
    exit 0
fi

[[ "$EUID" -eq 0 ]] || die 'Run as root, for example with sudo.'
for name in docker-compose.yml Dockerfile .env.example Caddyfile.site Caddyfile.site-custom; do
    [[ -f "$SCRIPT_DIR/templates/$name" ]] || die "Missing template: templates/$name"
done
if ! command -v openssl >/dev/null 2>&1 || ! command -v curl >/dev/null 2>&1 || ! command -v tar >/dev/null 2>&1; then
    [[ "$SKIP_DEPENDENCIES" != '1' ]] || die 'openssl, curl and tar are required.'
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    apt-get install -y --no-install-recommends ca-certificates openssl curl tar
fi
command -v realpath >/dev/null 2>&1 || die 'realpath (coreutils) is required.'

validate_domain() {
    local domain="$1"
    [[ -n "$domain" ]] || die 'A domain is required.'
    [[ "$domain" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$ ]] || die 'Invalid domain.'
    [[ "$domain" != *'..'* && "$domain" != *'.-'* && "$domain" != *'-.'* ]] || die 'Invalid domain labels.'
    if [[ "$domain" != 'localhost' ]]; then
        [[ "$domain" == *.* ]] || die 'Use a fully qualified domain name.'
        [[ ! "$domain" =~ ^[0-9.]+$ ]] || die 'Use a domain rather than an IP address.'
    fi
}
validate_port() {
    local value="$2"
    [[ "$value" =~ ^[0-9]+$ ]] || die "$1 must be numeric."
    (( value >= 1 && value <= 65535 )) || die "$1 is outside the valid range."
}
if [[ -n "$REQUESTED_DOMAIN" ]]; then
    validate_domain "$REQUESTED_DOMAIN"
fi
validate_port BLOG_PORT "$BLOG_PORT"
validate_port HTTP_PORT "$HTTP_PORT"
validate_port HTTPS_PORT "$HTTPS_PORT"
[[ "$COMPOSE_PROJECT_NAME" =~ ^[a-z][a-z0-9-]*$ ]] || die 'Invalid Compose project name.'
[[ "$BLOG_SUBNET" =~ ^[0-9.]+/[0-9]+$ ]] || die 'Invalid BLOG_SUBNET.'
[[ "$BLOG_GATEWAY" =~ ^[0-9.]+$ ]] || die 'Invalid BLOG_GATEWAY.'

install_docker() {
    [[ "$SKIP_DEPENDENCIES" != '1' ]] || die 'Docker is missing and dependency installation is disabled.'
    [[ -r /etc/os-release ]] || die 'Cannot detect the operating system.'
    # shellcheck disable=SC1091
    . /etc/os-release
    [[ "${ID:-}" == 'debian' || "${ID:-}" == 'ubuntu' ]] || die 'Automatic Docker installation supports Debian/Ubuntu.'
    local codename="${VERSION_CODENAME:-${UBUNTU_CODENAME:-}}"
    [[ -n "$codename" ]] || die 'Cannot determine the distribution codename.'
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    apt-get install -y --no-install-recommends ca-certificates curl gnupg openssl
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL "https://download.docker.com/linux/${ID}/gpg" -o /etc/apt/keyrings/docker.asc
    chmod a+r /etc/apt/keyrings/docker.asc
    printf 'deb [arch=%s signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/%s %s stable\n' \
        "$(dpkg --print-architecture)" "$ID" "$codename" > /etc/apt/sources.list.d/docker.list
    apt-get update
    apt-get install -y --no-install-recommends \
        docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
}

if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
    install_docker
fi
if ! command -v caddy >/dev/null 2>&1; then
    [[ "$SKIP_DEPENDENCIES" != '1' ]] || die 'Caddy is missing and dependency installation is disabled.'
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    apt-get install -y --no-install-recommends caddy
fi
if command -v systemctl >/dev/null 2>&1; then
    systemctl enable --now docker
fi
docker info >/dev/null 2>&1 || die 'Docker daemon is unavailable.'

INSTALL_DIR="$(realpath -m "$INSTALL_DIR")"
CADDY_CONFIG_ROOT="$(realpath -m "$CADDY_CONFIG_ROOT")"
case "$CADDY_CONFIG_ROOT" in
    /|/boot|/dev|/etc|/usr|/var|/root|/home|/opt|/opt/docker|/srv|/tmp|/run|/proc|/sys)
        die "Unsafe Caddy configuration directory: $CADDY_CONFIG_ROOT" ;;
esac
[[ "$INSTALL_DIR$CADDY_CONFIG_ROOT" != *' '* ]] || die 'Paths containing spaces are not supported.'
case "$INSTALL_DIR" in
    /|/boot|/dev|/etc|/usr|/var|/root|/home|/opt|/opt/docker|/srv|/tmp|/run|/proc|/sys)
        die "Unsafe installation directory: $INSTALL_DIR" ;;
esac
[[ ! -L "$INSTALL_DIR" ]] || die 'INSTALL_DIR must not be a symbolic link.'
if [[ -e "$INSTALL_DIR" && ! -d "$INSTALL_DIR" ]]; then
    die 'INSTALL_DIR exists but is not a directory.'
fi
if [[ ! -d "$INSTALL_DIR" ]]; then
    mkdir -p "$INSTALL_DIR"
    chmod 0755 "$INSTALL_DIR"
fi
[[ "$(stat -c %u "$INSTALL_DIR")" == '0' ]] || die 'Installation directory must be owned by root.'
cd "$INSTALL_DIR"
shopt -s nullglob dotglob
entries=(*)
shopt -u nullglob dotglob
if (( ${#entries[@]} > 0 )) && [[ ! -f "$MARKER" ]]; then
    die 'Non-empty directory is not a recognized one-click installation.'
fi
if [[ ! -f "$MARKER" ]]; then
    printf 'version=%s\nproject=%s\n' "$VERSION" "$COMPOSE_PROJECT_NAME" > "$MARKER"
    chmod 0644 "$MARKER"
fi

if [[ ! -f .env && -z "$REQUESTED_DOMAIN" ]]; then
    die 'A domain is required for a new installation.'
fi
if [[ ! -f .env ]]; then
    log 'Creating .env with random database and WordPress secrets.'
    PUBLIC_HTTPS_ORIGIN="https://${REQUESTED_DOMAIN}"
    if [[ "$HTTPS_PORT" != '443' ]]; then
        PUBLIC_HTTPS_ORIGIN="${PUBLIC_HTTPS_ORIGIN}:${HTTPS_PORT}"
    fi
    env_tmp="$(mktemp '.env.tmp.XXXXXX')"
    sed \
        -e "s|__DOMAIN__|$REQUESTED_DOMAIN|g" \
        -e "s|__PUBLIC_HTTPS_ORIGIN__|$PUBLIC_HTTPS_ORIGIN|g" \
        -e "s|__COMPOSE_PROJECT_NAME__|$COMPOSE_PROJECT_NAME|g" \
        -e "s|__BLOG_PORT__|$BLOG_PORT|g" \
        -e "s|__HTTP_PORT__|$HTTP_PORT|g" \
        -e "s|__HTTPS_PORT__|$HTTPS_PORT|g" \
        -e "s|__BLOG_SUBNET__|$BLOG_SUBNET|g" \
        -e "s|__BLOG_GATEWAY__|$BLOG_GATEWAY|g" \
        -e "s|__MARIADB_PASSWORD__|$(openssl rand -hex 32)|g" \
        -e "s|__MARIADB_ROOT_PASSWORD__|$(openssl rand -hex 32)|g" \
        -e "s|__WORDPRESS_AUTH_KEY__|$(openssl rand -hex 32)|g" \
        -e "s|__WORDPRESS_SECURE_AUTH_KEY__|$(openssl rand -hex 32)|g" \
        -e "s|__WORDPRESS_LOGGED_IN_KEY__|$(openssl rand -hex 32)|g" \
        -e "s|__WORDPRESS_NONCE_KEY__|$(openssl rand -hex 32)|g" \
        -e "s|__WORDPRESS_AUTH_SALT__|$(openssl rand -hex 32)|g" \
        -e "s|__WORDPRESS_SECURE_AUTH_SALT__|$(openssl rand -hex 32)|g" \
        -e "s|__WORDPRESS_LOGGED_IN_SALT__|$(openssl rand -hex 32)|g" \
        -e "s|__WORDPRESS_NONCE_SALT__|$(openssl rand -hex 32)|g" \
        "$SCRIPT_DIR/templates/.env.example" > "$env_tmp"
    chmod 0600 "$env_tmp"
    mv "$env_tmp" .env
else
    warn 'Reusing existing .env; secrets will not be regenerated or printed.'
fi
chmod 0600 .env

get_env() {
    sed -n "s/^$1=//p" .env | tail -n 1
}
DOMAIN="$(get_env DOMAIN)"
COMPOSE_PROJECT_NAME="$(get_env COMPOSE_PROJECT_NAME)"
BLOG_PORT="$(get_env BLOG_PORT)"
BLOG_SUBNET="$(get_env BLOG_SUBNET)"
BLOG_GATEWAY="$(get_env BLOG_GATEWAY)"
stored_http_port="$(get_env HTTP_PORT)"
stored_https_port="$(get_env HTTPS_PORT)"
if [[ -n "$stored_http_port" && -n "$EXPLICIT_HTTP_PORT" && "$stored_http_port" != "$EXPLICIT_HTTP_PORT" ]]; then
    die 'HTTP_PORT conflicts with the existing .env value.'
fi
if [[ -n "$stored_https_port" && -n "$EXPLICIT_HTTPS_PORT" && "$stored_https_port" != "$EXPLICIT_HTTPS_PORT" ]]; then
    die 'HTTPS_PORT conflicts with the existing .env value.'
fi
if [[ -n "$stored_http_port" ]]; then
    HTTP_PORT="$stored_http_port"
fi
if [[ -n "$stored_https_port" ]]; then
    HTTPS_PORT="$stored_https_port"
fi
if [[ -z "$stored_http_port" || -z "$stored_https_port" ]]; then
    ports_tmp="$(mktemp '.env.ports.tmp.XXXXXX')"
    cat .env > "$ports_tmp"
    if [[ -z "$stored_http_port" ]]; then
        printf 'HTTP_PORT=%s\n' "$HTTP_PORT" >> "$ports_tmp"
    fi
    if [[ -z "$stored_https_port" ]]; then
        printf 'HTTPS_PORT=%s\n' "$HTTPS_PORT" >> "$ports_tmp"
    fi
    chmod 0600 "$ports_tmp"
    mv "$ports_tmp" .env
fi
for key in MARIADB_DATABASE MARIADB_USER MARIADB_PASSWORD MARIADB_ROOT_PASSWORD \
    WORDPRESS_AUTH_KEY WORDPRESS_SECURE_AUTH_KEY WORDPRESS_LOGGED_IN_KEY WORDPRESS_NONCE_KEY \
    WORDPRESS_AUTH_SALT WORDPRESS_SECURE_AUTH_SALT WORDPRESS_LOGGED_IN_SALT WORDPRESS_NONCE_SALT; do
    [[ -n "$(get_env "$key")" ]] || die "$key is missing from .env"
done
: "${BLOG_PORT:?BLOG_PORT is missing}"
: "${BLOG_SUBNET:?BLOG_SUBNET is missing}"
: "${BLOG_GATEWAY:?BLOG_GATEWAY is missing}"
: "${COMPOSE_PROJECT_NAME:?COMPOSE_PROJECT_NAME is missing}"
if [[ -n "$REQUESTED_DOMAIN" && "${REQUESTED_DOMAIN,,}" != "${DOMAIN,,}" ]]; then
    die 'The requested domain differs from the existing .env domain.'
fi
validate_domain "$DOMAIN"
validate_port BLOG_PORT "$BLOG_PORT"
validate_port HTTP_PORT "$HTTP_PORT"
validate_port HTTPS_PORT "$HTTPS_PORT"
export DOMAIN COMPOSE_PROJECT_NAME BLOG_PORT BLOG_SUBNET BLOG_GATEWAY HTTP_PORT HTTPS_PORT

computed_origin="https://${DOMAIN}"
if [[ "$HTTPS_PORT" != '443' ]]; then
    computed_origin="${computed_origin}:${HTTPS_PORT}"
fi
registered_origin="$(get_env PUBLIC_HTTPS_ORIGIN)"
if [[ -n "$registered_origin" && "$registered_origin" != "$computed_origin" ]]; then
    die 'PUBLIC_HTTPS_ORIGIN in .env does not match DOMAIN and HTTPS_PORT.'
fi
if [[ -z "$registered_origin" ]]; then
    origin_tmp="$(mktemp '.env.origin.tmp.XXXXXX')"
    cat .env > "$origin_tmp"
    printf 'PUBLIC_HTTPS_ORIGIN=%s\n' "$computed_origin" >> "$origin_tmp"
    chmod 0600 "$origin_tmp"
    mv "$origin_tmp" .env
fi
PUBLIC_HTTPS_ORIGIN="$computed_origin"
export PUBLIC_HTTPS_ORIGIN

render_template() {
    local source="$1"
    local target="$2"
    local mode="${3:-0644}"
    [[ ! -L "$target" ]] || die "$target must not be a symbolic link."
    if [[ -e "$target" && ! -f "$target" ]]; then
        die "$target exists but is not a regular file."
    fi
    if [[ -f "$target" ]]; then
        warn "Keeping existing $target"
        return
    fi
    local temporary
    temporary="$(mktemp "${target}.tmp.XXXXXX")"
    sed \
        -e "s|__DOMAIN__|$DOMAIN|g" \
        -e "s|__BLOG_PORT__|$BLOG_PORT|g" \
        -e "s|__BLOG_GATEWAY__|$BLOG_GATEWAY|g" \
        -e "s|__HTTP_PORT__|$HTTP_PORT|g" \
        -e "s|__HTTPS_PORT__|$HTTPS_PORT|g" \
        -e "s|__PUBLIC_HTTPS_ORIGIN__|$PUBLIC_HTTPS_ORIGIN|g" \
        "$source" > "$temporary"
    chmod "$mode" "$temporary"
    mv "$temporary" "$target"
}

mkdir -p nginx/logs php/conf.d php/php-fpm.d www
render_template "$SCRIPT_DIR/templates/docker-compose.yml" docker-compose.yml
render_template "$SCRIPT_DIR/templates/Dockerfile" Dockerfile
render_template "$SCRIPT_DIR/templates/nginx/nginx.conf" nginx/nginx.conf
render_template "$SCRIPT_DIR/templates/nginx/default.conf" nginx/default.conf
render_template "$SCRIPT_DIR/templates/php/conf.d/99-blog.ini" php/conf.d/99-blog.ini
render_template "$SCRIPT_DIR/templates/php/php-fpm.d/zz-blog.ini" php/php-fpm.d/zz-blog.ini
created_wp_config=0
if [[ ! -f www/wp-config.php ]]; then
    created_wp_config=1
fi
render_template "$SCRIPT_DIR/templates/www/wp-config.php" www/wp-config.php 0640

downloaded_wordpress=0
if [[ ! -f www/index.php ]]; then
    downloaded_wordpress=1
    log 'Downloading WordPress into www/.'
    download_dir="$(mktemp -d)"
    curl -fsSL "$WORDPRESS_DOWNLOAD_URL" -o "$download_dir/wordpress.tar.gz"
    tar -xzf "$download_dir/wordpress.tar.gz" -C "$download_dir"
    cp -a "$download_dir/wordpress/." www/
    rm -rf -- "$download_dir"
else
    warn 'Keeping the existing WordPress files in www/.'
fi
render_template "$SCRIPT_DIR/templates/www/wp-config.php" www/wp-config.php 0640
if [[ "$downloaded_wordpress" == '1' ]]; then
    chown -R 33:33 www
    find www -type d -exec chmod 2775 {} +
    find www -type f -exec chmod 0664 {} +
fi
if [[ "$created_wp_config" == '1' && -f www/wp-config.php ]]; then
    chown 33:33 www/wp-config.php
    chmod 0640 www/wp-config.php
fi

compose() {
    docker compose --project-name "$COMPOSE_PROJECT_NAME" --env-file .env \
        -f docker-compose.yml "$@"
}

log 'Validating the Compose model.'
compose config -q
if [[ "$PULL_IMAGES" == '1' ]]; then
    log 'Pulling Docker images.'
    compose pull db redis nginx
fi
log 'Building and starting the WordPress containers.'
compose up -d --build

for service_name in db redis php nginx; do
    container_name="${COMPOSE_PROJECT_NAME}-${service_name}"
    healthy=0
    for attempt in $(seq 1 60); do
        status="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$container_name" 2>/dev/null || true)"
        if [[ "$status" == 'healthy' ]]; then
            healthy=1
            break
        fi
        sleep 5
    done
    [[ "$healthy" == '1' ]] || die "$container_name did not become healthy."
done

http_code="$(curl -sS --max-time 30 -o /dev/null -w '%{http_code}' \
    -H "Host: $DOMAIN" -H 'X-Forwarded-Proto: https' "http://127.0.0.1:${BLOG_PORT}/wp-admin/install.php")"
[[ "$http_code" == '200' ]] || die "WordPress origin returned HTTP $http_code."
printf 'WORDPRESS_ORIGIN_HTTP=%s\n' "$http_code"

mkdir -p "$CADDY_CONFIG_ROOT/sites.d"
main_caddyfile="$CADDY_CONFIG_ROOT/Caddyfile"
site_caddyfile="$CADDY_CONFIG_ROOT/sites.d/${DOMAIN}.conf"
import_line="import ${CADDY_CONFIG_ROOT}/sites.d/*.conf"
custom_ports=0
if [[ "$HTTP_PORT" != '80' || "$HTTPS_PORT" != '443' ]]; then
    custom_ports=1
fi

if [[ -f "$site_caddyfile" ]]; then
    warn "Keeping existing Caddy site config: $site_caddyfile"
else
    if [[ -f "$main_caddyfile" ]] && grep -Fq "$DOMAIN" "$main_caddyfile"; then
        die 'The domain already appears in the main Caddyfile; review it before continuing.'
    fi
    if [[ "$custom_ports" == '1' ]]; then
        render_template "$SCRIPT_DIR/templates/Caddyfile.site-custom" "$site_caddyfile"
    else
        render_template "$SCRIPT_DIR/templates/Caddyfile.site" "$site_caddyfile"
    fi
fi

if [[ ! -f "$main_caddyfile" ]]; then
    main_tmp="$(mktemp "${main_caddyfile}.tmp.XXXXXX")"
    if [[ "$custom_ports" == '1' ]]; then
        printf '{\n\tauto_https disable_redirects\n\thttp_port %s\n\thttps_port %s\n}\n\n%s\n' \
            "$HTTP_PORT" "$HTTPS_PORT" "$import_line" > "$main_tmp"
    else
        printf '%s\n' "$import_line" > "$main_tmp"
    fi
    chmod 0644 "$main_tmp"
    mv "$main_tmp" "$main_caddyfile"
elif ! grep -Fxq "$import_line" "$main_caddyfile"; then
    if [[ "$custom_ports" == '1' ]]; then
        die 'Custom ports require a recognized isolated Caddyfile; refusing to alter an existing global configuration.'
    fi
    main_tmp="$(mktemp "${main_caddyfile}.tmp.XXXXXX")"
    cp -a "$main_caddyfile" "${main_caddyfile}.backup-$(date -u +%Y%m%dT%H%M%SZ)"
    cat "$main_caddyfile" > "$main_tmp"
    printf '\n%s\n' "$import_line" >> "$main_tmp"
    chmod 0644 "$main_tmp"
    caddy validate --config "$main_tmp" --adapter caddyfile
    mv "$main_tmp" "$main_caddyfile"
fi

log 'Validating the complete host Caddy configuration.'
caddy validate --config "$main_caddyfile" --adapter caddyfile

if [[ "$CADDY_CONFIG_ROOT" != '/etc/caddy' && "$SKIP_SERVICE_ACTIONS" != '1' ]]; then
    die 'A custom CADDY_CONFIG_ROOT requires SKIP_SERVICE_ACTIONS=1 to avoid touching the system Caddy service.'
fi
if [[ "$SKIP_SERVICE_ACTIONS" != '1' ]]; then
    systemctl enable --now caddy
    systemctl reload-or-restart caddy
fi

if [[ "$SKIP_SERVICE_ACTIONS" != '1' ]]; then
    connect_ip='127.0.0.1'
    curl_insecure=()
    if [[ "$DOMAIN" == 'localhost' ]]; then
        curl_insecure=(-k)
    fi
    public_port=''
    if [[ "$HTTPS_PORT" != '443' ]]; then
        public_port=":$HTTPS_PORT"
    fi
    public_http_port=''
    if [[ "$HTTP_PORT" != '80' ]]; then
        public_http_port=":$HTTP_PORT"
    fi
    https_code="$(curl "${curl_insecure[@]}" -L -sS --max-time 30 \
        --resolve "${DOMAIN}:${HTTPS_PORT}:${connect_ip}" \
        -o /dev/null -w '%{http_code}' "https://${DOMAIN}${public_port}/")"
    [[ "$https_code" == '200' ]] || die "Public HTTPS returned HTTP $https_code."
    expected_redirect="${PUBLIC_HTTPS_ORIGIN}/wp-admin/install.php"
    redirect_result="$(curl -sS --max-time 20 \
        --resolve "${DOMAIN}:${HTTP_PORT}:${connect_ip}" \
        -o /dev/null -w '%{http_code} %{redirect_url}' \
        "http://${DOMAIN}${public_http_port}/wp-admin/install.php")"
    [[ "${redirect_result%% *}" == '308' ]] || die 'Unexpected HTTP redirect status.'
    [[ "${redirect_result#* }" == "$expected_redirect" ]] || die 'Unexpected HTTP redirect target.'
    printf 'PUBLIC_HTTPS_HTTP=%s\n' "$https_code"
    printf 'HTTP_REDIRECT=%s\n' "${redirect_result#* }"
fi

printf '\n\033[1;32m[SUCCESS]\033[0m Deployment is complete.\n'
printf 'WordPress directory: %s\n' "$INSTALL_DIR"
printf 'Caddy configuration: %s\n' "$main_caddyfile"
printf 'Website: %s\n' "$PUBLIC_HTTPS_ORIGIN"
printf 'Finish setup: %s/wp-admin/install.php\n' "$PUBLIC_HTTPS_ORIGIN"
printf 'Manage containers: cd %s && docker compose ps\n' "$INSTALL_DIR"
if [[ "$SKIP_SERVICE_ACTIONS" == '1' ]]; then
    printf 'Host Caddy was validated but not started. Start it with: caddy run --config %s\n' "$main_caddyfile"
fi
